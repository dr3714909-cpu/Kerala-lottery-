// Change only this file when the date or prizes change.
const DRAW_DATE="20 September 2026";
const RESULTS=[
{ticket:"KL-1458",prize:"₹75,000",category:"Prize"},
{ticket:"KL-8566",prize:"₹50,000",category:"Prize"},
{ticket:"KL-5839",prize:"₹10,000",category:"Prize"},
{ticket:"KL-4268",prize:"₹1,00,000",category:"Prize"},
{ticket:"KL-2285",prize:"₹5,000",category:"Prize"},
{ticket:"KL-5868",prize:"₹40,000",category:"Prize"}];